
# 💳 EXPERTPAY – Online Banking Website (Demo)

**EXPERTPAY** is a mock online banking platform built for demonstration, educational, and portfolio purposes. It includes user registration, login, a user dashboard to view balance and bank details, and an admin panel for managing transactions.

> ⚠️ This project is not connected to any real financial system or services. No actual payments or data are processed.

---

## 🚀 Features

- ✅ User Login & Registration Interface
- ✅ Dashboard with:
  - Balance display
  - Deposit & Withdrawal request buttons
  - Static bank details
- ✅ Admin Panel:
  - View/manage transaction requests (static)
- ✅ Mobile-responsive layout (HTML + CSS)
- ✅ Contact link via email
- ✅ Easy to deploy on Netlify or GitHub Pages

---

## 📂 Project Structure

```
expertpay-site/
│
├── index.html          # Main homepage with all sections
├── styles.css          # Basic styling for layout
├── README.md           # Project info and usage guide
```

---

## 🏦 Bank Info (Static Content)

Displayed on user dashboard:

- **Account Holder**: EXPERTPAY BOTSWANA  
- **Bank**: First National Bank  
- **Account Number**: 62198602586  
- **Branch Code**: 284567  
- **Currency**: BWP

---

## 📬 Contact

For any inquiries regarding this project:

📧 Email: [payexpert00@gmail.com](mailto:payexpert00@gmail.com)

---

## 📡 Hosting

You can deploy this project for free using:

- [Netlify](https://www.netlify.com/) – drag & drop support  
- [GitHub Pages](https://pages.github.com/) – static hosting via repo  

---

## ⚠️ Disclaimer

This is a **demo project only** and not intended for real banking use. It does not support real user authentication, encryption, or data storage.

---
